import torch

def rbf_kernel(X1: torch.Tensor, X2: torch.Tensor, gamma: float=None) -> torch.Tensor:
    """
    Computes the Radial Basis Function (RBF) kernel between two sets of points.

    Args:
        X1 (torch.Tensor): First  set of points, shape (n_1, n_features).
        X2 (torch.Tensor): Second set of points, shape (n_2, n_features).
        gamma (float, optional): Parameter for the RBF kernel. If None, it is set to 1 / n_features.

    Returns:
        torch.Tensor: RBF kernel matrix of shape (n_1, n_2).
    """
    X1 = X1.double()
    X2 = X2.double()
    if X1.dim() == 1:       # (n_features)
        X1 = X1.unsqueeze(0)
    if X2.dim() == 1:       # (n_features)
        X2 = X2.unsqueeze(0)

    # X1: (n_1, n_features), X2: (n_2, n_features)
    assert X1.shape[-1] == X2.shape[-1], "X1 and X2 must have the same number of features."

    if gamma is None:
        gamma = 1.0 / X1.shape[1]

    return torch.exp(-gamma * torch.cdist(X1, X2, p=2) ** 2)

    chunk_size = 8192
    results = []

    for i in range(0, X1.shape[0], chunk_size):
        X1_chunk = X1[i : i + chunk_size]
        sq_dists_chunk = torch.cdist(X1_chunk, X2, p=2) ** 2
        results.append(torch.exp(-gamma * sq_dists_chunk))

    return torch.cat(results, dim=0)

def one_hot(Y: torch.Tensor, n_classes: int) -> torch.Tensor:
    """
    Converts class labels to one-hot encoded format.

    Args:
        Y (torch.Tensor): Class labels, shape (n_samples,).
        n_classes (int): Number of classes.

    Returns:
        torch.Tensor: One-hot encoded tensor of shape (n_samples, n_classes).
    """
    if Y.dim() == 2:
        Y.squeeze_(-1)  # Ensure Y is 1D if it has a single dimension
    assert Y.dim() == 1, "Y must be a 1D tensor of class labels."
    assert Y.max() < n_classes, "Class labels must be less than n_classes."
    return torch.nn.functional.one_hot(Y, num_classes=n_classes).float()

def idx_to_one_hot(idx: int, n_classes: int) -> torch.Tensor:
    """
    Converts an index to a one-hot encoded tensor.

    Args:
        idx (int): Index to convert.
        n_classes (int): Number of classes.

    Returns:
        torch.Tensor: One-hot encoded tensor of shape (n_classes,).
    """
    assert 0 <= idx < n_classes, "Index must be within the range of classes."
    one_hot = torch.zeros(n_classes)
    one_hot[idx] = 1.0
    return one_hot

def indices_to_one_hot(indices: list, n_classes: int) -> torch.Tensor:
    """
    Converts a tensor of indices to a one-hot encoded tensor.

    Args:
        indices (torch.Tensor): Tensor of indices, shape (n_indices,).
        n_classes (int): Number of classes.
    Returns:
        torch.Tensor: One-hot encoded tensor of shape (n_indices, n_classes).
    """
    one_hot = torch.zeros(len(indices), n_classes)
    one_hot[torch.arange(len(indices)), indices] = 1.0
    return one_hot