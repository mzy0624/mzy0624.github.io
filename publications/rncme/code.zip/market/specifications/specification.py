from .cme   import CME
from .ncme  import NCME
from .rkme  import RKME
from .rncme import RNCME
from .lp    import LinearProxy
from .hf    import HeterogeneousFeature
from .crkme import ClassWiseRKME
from .rncme_time import RNCMETime
import torch
from datasets import Dataset
from time import time

class Specification:
    def __init__(self, cfg, role, role_id, **kwargs):
        self.cfg = cfg
        self.role = role
        self.role_id = role_id
        spec = cfg['specification']
        X, Y = Dataset(cfg, role, role_id).specification_data(100)
        self.spec = eval(spec)(cfg, X=X, Y=Y, **kwargs)
        self.spec.generate(**kwargs)
        torch.cuda.empty_cache()

    def __getattr__(self, name):
        if name in self.__dict__:
            return self.__dict__[name]

        if hasattr(self.__class__, name):
            return getattr(self.__class__, name)

        return getattr(self.spec, name)

    def compare(self, other_spec, **kwargs):
        return self.spec.compare(other_spec.spec, **kwargs)