import hydra
from omegaconf import OmegaConf
from utils import parallel, set_seed
import numpy as np
from metric import NDCG_at_k_rank, ensemble_average_accuracy
from market import Market
from user import User
import numpy as np

@hydra.main(version_base=None, config_path='configs', config_name='config')
def main(cfg=None):
    cfg = OmegaConf.to_container(cfg, resolve=True)
    cfg.update(cfg['task'])
    cfg.update(cfg['specification'])
    set_seed(cfg['seed'])
    market = Market(cfg)
    # parallel(cfg['n_learnware'], market.submit_learnware)
    # parallel(cfg['n_user'], User, cfg)
    # return
    for learnware_id in range(1, 1 + cfg['n_learnware']):
        market.submit_learnware(learnware_id)
    print('')
    users = [User(cfg, user_id) for user_id in range(1, 1 + cfg['n_user'])]
    model_perfs = np.array([market.evaluate (user)[0] for user in users])
    rcmd_orders = np.array([market.recommend(user)    for user in users])
    print(NDCG_at_k_rank(cfg, rcmd_orders, model_perfs, k=1))
    # print(NDCG_at_k_rank(cfg, rcmd_orders, model_perfs))
    # if cfg['task'] == 'classification':
    #     print(ensemble_average_accuracy(cfg, rcmd_orders))


if __name__ == '__main__':
    main()
