from .nico      import NICOFeature
from .housing   import CaliforniaHousing
from .synthetic import Synthetic

class Dataset:
    def __init__(self, cfg, role=None, role_id=None):
        self.cfg = cfg
        self.task = cfg['task']
        if self.task == 'classification':
            self.dataset = NICOFeature(cfg, role, role_id)
        elif self.task == 'regression':
            self.dataset = CaliforniaHousing(cfg, role, role_id)
        else:            # synthetic
            self.dataset = Synthetic(cfg)

    def get_data(self, split, n_samples=None):
        # return a tuple of (X, Y)
        return self.dataset.get_data(split, n_samples=n_samples)

    def specification_data(self, n_samples=None):
        return self.dataset.specification_data(n_samples)

    def get_loader(self, split=None):
        return self.dataset.get_loader(split)